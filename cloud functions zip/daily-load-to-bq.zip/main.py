import os
import pandas as pd
from io import StringIO
from google.cloud import storage, bigquery

# Environment variables
TEMP_GCS_BUCKET = os.environ.get('TEMP_GCS_BUCKET')
BIGQUERY_DATASET = os.getenv('BIGQUERY_DATASET')
BIGQUERY_TABLE = os.getenv('BIGQUERY_TABLE')

def process_csv_data(request):
    # Initialize clients
    storage_client = storage.Client()
    bigquery_client = bigquery.Client()

    # Reference to the bucket
    bucket = storage_client.bucket(TEMP_GCS_BUCKET)
    blobs = bucket.list_blobs()

    processed = False
    for blob in blobs:
        if blob.name.endswith('.csv'):
            try:
                # Read CSV file from GCS bucket
                csv_content = blob.download_as_string()
                df = pd.read_csv(StringIO(csv_content.decode('utf-8')))
                df = apply_transformations(df)

                # Load data into BigQuery
                table_id = f"{BIGQUERY_DATASET}.{BIGQUERY_TABLE}"
                job = bigquery_client.load_table_from_dataframe(df, table_id, job_config=bigquery.LoadJobConfig(write_disposition="WRITE_APPEND"))
                job.result()

                print(f"Processed file {blob.name} and loaded data into {table_id}")
                processed = True
                break  # Exit after processing the first CSV file
            except Exception as e:
                print(f"Error processing file {blob.name}: {e}")

    if not processed:
        return "No CSV files found to process", 200

    # Empty the bucket after processing
    try:
        for b in bucket.list_blobs():
            b.delete()
        print("Emptied the bucket after processing.")
    except Exception as e:
        print(f"Error emptying the bucket: {e}")
        return "Error emptying the bucket", 500

    return "Processing complete", 200


def apply_transformations(df):
    # Rename 'datetime' column to 'date' and convert to DATE type
    if 'datetime' in df.columns:
        df['date'] = pd.to_datetime(df['datetime']).dt.date
        df.drop('datetime', axis=1, inplace=True)

    # Remove specific columns
    columns_to_remove = ['name', 'preciptype', 'conditions', 'severerisk', 'description', 'icon', 'stations']
    df = df.drop(columns=columns_to_remove, errors='ignore')

    # Transform 'sunset' and 'sunrise' columns to TIME
    for col in ['sunset', 'sunrise']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col]).dt.time

    # Convert integers to floats
    df = df.astype({col: 'float64' for col in df.select_dtypes('int64').columns})

    return df