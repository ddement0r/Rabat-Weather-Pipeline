import os
import datetime
import requests
import io
from google.cloud import storage, scheduler_v1
from flask import jsonify
from google.api_core.exceptions import GoogleAPICallError

def delete_scheduler_job():
    project_id = os.environ.get('GCP_PROJECT_ID')
    location = os.environ.get('GCP_LOCATION')
    job_name = os.environ.get('SCHEDULER_JOB_NAME')  # The name of the scheduler job
    client = scheduler_v1.CloudSchedulerClient()
    job_path = client.job_path(project_id, location, job_name)

    try:
        client.delete_job(name=job_path)
        print(f"Job {job_name} deleted.")
    except GoogleAPICallError as error:
        print(f"Failed to delete job: {error}")

def get_weather_data(request):
    try:
        # Environment variables for API and GCS
        base_url = os.environ.get('WEATHER_API_BASE_URL')
        location = os.environ.get('WEATHER_LOCATION')
        api_key = os.environ.get('WEATHER_API_KEY')
        include_param = os.environ.get('INCLUDE_PARAM')
        unit_group = os.environ.get('UNIT_GROUP')
        initial_processing_endpoint = os.environ.get('INITIAL_PROCESSING_ENDPOINT')
        bucket_name = os.environ.get('GCS_BUCKET')
        
        # Initialize Google Cloud Storage client
        storage_client = storage.Client()

        # Date range from 1st Jan 2023 to today
        start_date = datetime.date(2023, 1, 1)
        end_date = datetime.date.today()
        delta = datetime.timedelta(days=1)

        # Loop over each day in the range
        while start_date <= end_date:
            file_date = start_date.strftime('%Y-%m-%d')
            api_url = f"{base_url}/{location}/{file_date}/{file_date}?unitGroup={unit_group}&include={include_param}&key={api_key}&contentType=csv"

            # Make the API call
            response = requests.get(api_url)
            response.raise_for_status()

            if response.content.strip():
                # Folder path and file name
                folder_path = start_date.strftime('%Y/%m/%d')
                file_name = f"{start_date.strftime('%d-%m-%Y')}.csv"
                blob_name = f"{folder_path}/{file_name}"

                # Upload to Google Cloud Storage
                bucket = storage_client.bucket(bucket_name)
                blob = bucket.blob(blob_name)
                blob.upload_from_string(response.content, content_type='text/csv')

            # Move to the next day
            start_date += delta
        # Delete Scheduler Job
        delete_scheduler_job()
        # Trigger the processing function
        requests.get(initial_processing_endpoint)
        return jsonify({"message": "Data upload completed, and the processing is triggered"}), 200

    except requests.exceptions.RequestException as req_err:
        return jsonify({"error": f"Request error: {req_err}"}), 500
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500