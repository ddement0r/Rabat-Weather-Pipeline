import os
import datetime
import requests
from google.cloud import storage
from flask import jsonify

def get_weather_data(request):
    try:
        # Environment variables for API
        base_url = os.environ.get('WEATHER_API_BASE_URL')
        location = os.environ.get('WEATHER_LOCATION')
        api_key = os.environ.get('WEATHER_API_KEY')
        include_param = os.environ.get('INCLUDE_PARAM')
        unit_group = os.environ.get('UNIT_GROUP')

        daily_processing_endpoint = os.environ.get('DAILY_PROCESSING_ENDPOINT')
        
        # Environment variables for GCS Buckets
        bucket_name = os.environ.get('GCS_BUCKET')  # Historical bucket
        temp_bucket_name = os.environ.get('TEMP_GCS_BUCKET')  # Temporary bucket

        # Initialize Google Cloud Storage client
        storage_client = storage.Client()

        # Today's date for the API call and file naming
        today = datetime.datetime.now()
        today_date = today.strftime('%Y-%m-%d')
        api_url = f"{base_url}/{location}/{today_date}/{today_date}?unitGroup={unit_group}&include={include_param}&key={api_key}&contentType=csv"
        folder_path = today.strftime('%Y/%m/%d')
        file_name = f"{today.strftime('%d-%m-%Y')}.csv"
        blob_name = f"{folder_path}/{file_name}"

        # Make the API call and get CSV data
        response = requests.get(api_url)
        response.raise_for_status()

        # If the response is empty
        if not response.content.strip():
            return jsonify({"message": "No data returned from the API"}), 200

        # Upload to the historical bucket
        historical_bucket = storage_client.bucket(bucket_name)
        historical_blob = historical_bucket.blob(blob_name)
        historical_blob.upload_from_string(response.content, content_type='text/csv')

        # Upload to the temporary bucket
        temp_bucket = storage_client.bucket(temp_bucket_name)
        temp_blob = temp_bucket.blob(blob_name)
        temp_blob.upload_from_string(response.content, content_type='text/csv')
        # Trigger the processing function
        requests.get(daily_processing_endpoint)
        return jsonify({"message": f"Data for {today_date} uploaded to both buckets and the processing was triggered"}), 200

    except requests.exceptions.RequestException as req_err:
        return jsonify({"error": f"Request error: {req_err}"}), 500
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500
